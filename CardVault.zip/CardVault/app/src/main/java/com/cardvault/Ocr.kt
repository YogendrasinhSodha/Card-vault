package com.cardvault

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import androidx.exifinterface.media.ExifInterface
import cz.adaptech.tesseract4android.TessBaseAPI
import java.io.File
import kotlin.math.max

object Ocr {
    private val langs = listOf("eng.traineddata", "guj.traineddata")

    /** Copies language files from assets to internal storage (first run only). */
    private fun prepare(ctx: Context): String {
        val base = File(ctx.filesDir, "tess")
        val td = File(base, "tessdata").apply { mkdirs() }
        for (n in langs) {
            val f = File(td, n)
            if (!f.exists() || f.length() == 0L) {
                ctx.assets.open("tessdata/$n").use { i -> f.outputStream().use { o -> i.copyTo(o) } }
            }
        }
        return base.absolutePath
    }

    @Synchronized
    fun read(ctx: Context, bmp: Bitmap): String {
        val api = TessBaseAPI()
        try {
            if (!api.init(prepare(ctx), "eng+guj")) return ""
            api.setPageSegMode(TessBaseAPI.PageSegMode.PSM_AUTO)
            api.setImage(bmp)
            return (api.getUTF8Text() ?: "").trim()
        } finally {
            api.recycle()
        }
    }
}

object Images {
    private const val MAX_SIDE = 2000

    /** Loads the photo, fixes rotation, shrinks it, rewrites the file, returns the bitmap. */
    fun normalize(path: String): Bitmap {
        val opts = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(path, opts)
        var sample = 1
        while (max(opts.outWidth, opts.outHeight) / sample > MAX_SIDE * 2) sample *= 2
        val raw = BitmapFactory.decodeFile(path, BitmapFactory.Options().apply { inSampleSize = sample })
            ?: throw IllegalStateException("Cannot read photo")

        val rot = when (ExifInterface(path).getAttributeInt(ExifInterface.TAG_ORIENTATION, 1)) {
            ExifInterface.ORIENTATION_ROTATE_90 -> 90f
            ExifInterface.ORIENTATION_ROTATE_180 -> 180f
            ExifInterface.ORIENTATION_ROTATE_270 -> 270f
            else -> 0f
        }
        val scale = MAX_SIDE.toFloat() / max(raw.width, raw.height)
        val m = Matrix().apply {
            if (rot != 0f) postRotate(rot)
            if (scale < 1f) postScale(scale, scale)
        }
        val out = Bitmap.createBitmap(raw, 0, 0, raw.width, raw.height, m, true)
        File(path).outputStream().use { out.compress(Bitmap.CompressFormat.JPEG, 88, it) }
        return out
    }
}
