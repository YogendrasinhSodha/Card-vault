package com.cardvault

data class Parsed(
    val name: String = "", val company: String = "", val title: String = "",
    val phone: String = "", val email: String = "", val website: String = "",
    val address: String = ""
)

/** Simple rule-based field detection from OCR text (English + Gujarati). */
object Parse {
    private const val GUJ_DIGITS = "૦૧૨૩૪૫૬૭૮૯"
    private val emailRe = Regex("[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}")
    private val webRe = Regex(
        "(?:https?://)?www\\.[A-Za-z0-9.-]+\\.[A-Za-z]{2,}[^\\s,;]*|https?://[^\\s,;]+",
        RegexOption.IGNORE_CASE
    )
    private val phoneRe = Regex("\\+?\\d[\\d\\s().-]{7,}\\d")
    private val pinRe = Regex("\\b\\d{6}\\b")

    private val companyWords = listOf(
        "ltd", "limited", "pvt", "private", "industries", "industry", "corporation", "corp", "co.", "& co",
        "enterprise", "enterprises", "traders", "trading", "engineering", "engineers", "llp", "inc",
        "associates", "solutions", "systems", "technologies", "dairy", "agency", "agencies", "works",
        "લિમિટેડ", "પ્રા.", "ઉદ્યોગ", "એન્ટરપ્રાઇઝ", "ઇજનેરી", "ટ્રેડર્સ", "એન્જિનિયરિંગ"
    )
    private val titleWords = listOf(
        "manager", "director", "engineer", "proprietor", "partner", "ceo", "cfo", "coo", "head", "officer",
        "executive", "sales", "founder", "owner", "president", "vice", "consultant", "supervisor", "gm", "dgm",
        "મેનેજર", "ડિરેક્ટર", "ઇજનેર", "માલિક", "ભાગીદાર", "પ્રમુખ", "સંચાલક"
    )
    private val addressWords = listOf(
        "road", "rd.", "street", "society", "nagar", "estate", "plot", "floor", "gidc", "gujarat", "india",
        "opp.", "near", "building", "complex", "tower", "ahmedabad", "gandhinagar", "surat", "vadodara", "rajkot",
        "રોડ", "સોસાયટી", "નગર", "ગુજરાત", "અમદાવાદ", "ગાંધીનગર", "સુરત", "વડોદરા", "રાજકોટ", "પ્લોટ", "માળ"
    )

    private fun ascii(s: String) = buildString {
        for (ch in s) { val i = GUJ_DIGITS.indexOf(ch); append(if (i >= 0) '0' + i else ch) }
    }

    private fun hasAny(line: String, words: List<String>): Boolean {
        val l = line.lowercase()
        return words.any { l.contains(it) }
    }

    fun parse(raw: String): Parsed {
        val text = ascii(raw)
        val email = emailRe.find(text)?.value ?: ""
        val website = webRe.findAll(text).map { it.value }
            .firstOrNull { !it.contains("@") } ?: ""
        val phones = phoneRe.findAll(text).map { it.value.trim() }
            .filter { it.count(Char::isDigit) in 8..15 }.distinct().take(3).toList()

        val lines = text.lines().map { it.trim() }.filter { it.length > 1 }
        val plain = lines.filter { !emailRe.containsMatchIn(it) && !webRe.containsMatchIn(it) && !phoneRe.containsMatchIn(it) }

        val company = plain.firstOrNull { hasAny(it, companyWords) } ?: ""
        val title = plain.firstOrNull { it != company && hasAny(it, titleWords) } ?: ""
        val addrLines = lines.filter {
            !emailRe.containsMatchIn(it) && !webRe.containsMatchIn(it) &&
                (hasAny(it, addressWords) || pinRe.containsMatchIn(it))
        }
        val name = plain.firstOrNull {
            it != company && it != title && it !in addrLines &&
                it.none(Char::isDigit) && it.split(Regex("\\s+")).size in 1..4
        } ?: ""

        return Parsed(
            name = name, company = company, title = title,
            phone = phones.joinToString(", "), email = email, website = website,
            address = addrLines.joinToString(", ")
        )
    }
}
