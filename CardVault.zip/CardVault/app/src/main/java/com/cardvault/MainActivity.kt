package com.cardvault

import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.ContactsContract
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.core.content.FileProvider
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import coil.compose.AsyncImage
import kotlinx.coroutines.launch
import java.io.File
import java.util.UUID

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme { Surface(Modifier.fillMaxSize()) { App() } } }
    }
}

private fun launch(ctx: Context, intent: Intent) {
    try { ctx.startActivity(intent) }
    catch (e: ActivityNotFoundException) { Toast.makeText(ctx, "No app found for this action", Toast.LENGTH_SHORT).show() }
}

@Composable
fun App(vm: CardViewModel = viewModel()) {
    var screen by rememberSaveable { mutableStateOf("list") }
    var openId by rememberSaveable { mutableStateOf(0L) }
    BackHandler(enabled = screen != "list") { screen = "list" }
    when (screen) {
        "add" -> AddScreen(vm) { screen = "list" }
        "detail" -> DetailScreen(vm, openId) { screen = "list" }
        else -> ListScreen(vm, onAdd = { screen = "add" }, onOpen = { openId = it; screen = "detail" })
    }
}

// ---------------------------------------------------------------- LIST
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ListScreen(vm: CardViewModel, onAdd: () -> Unit, onOpen: (Long) -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val cards by vm.cards.collectAsStateWithLifecycle()
    val q by vm.query.collectAsStateWithLifecycle()
    val favOnly by vm.favOnly.collectAsStateWithLifecycle()
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Card Vault (${cards.size})") },
                actions = {
                    IconButton({ vm.favOnly.value = !favOnly }) {
                        Icon(if (favOnly) Icons.Default.Star else Icons.Default.StarBorder, "Favourites")
                    }
                    IconButton({ scope.launch { Export.shareCsv(ctx, vm.allCards()) } }) {
                        Icon(Icons.Default.Share, "Export all as CSV")
                    }
                })
        },
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = onAdd,
                icon = { Icon(Icons.Default.AddAPhoto, null) },
                text = { Text("Add card") })
        }
    ) { pad ->
        Column(Modifier.padding(pad).padding(horizontal = 12.dp)) {
            OutlinedTextField(
                value = q, onValueChange = { vm.query.value = it },
                modifier = Modifier.fillMaxWidth(),
                placeholder = { Text("Search name, company, phone… / શોધો") },
                leadingIcon = { Icon(Icons.Default.Search, null) },
                trailingIcon = {
                    if (q.isNotEmpty()) IconButton({ vm.query.value = "" }) { Icon(Icons.Default.Clear, null) }
                },
                singleLine = true
            )
            Spacer(Modifier.height(8.dp))
            if (cards.isEmpty()) {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text(if (q.isBlank() && !favOnly) "No cards yet. Tap “Add card”." else "No matches.")
                }
            } else {
                LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp), contentPadding = PaddingValues(bottom = 88.dp)) {
                    items(cards, key = { it.id }) { c ->
                        Card(Modifier.fillMaxWidth().clickable { onOpen(c.id) }) {
                            Row(Modifier.padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                                AsyncImage(
                                    model = File(c.frontPath), contentDescription = null,
                                    modifier = Modifier.size(width = 110.dp, height = 70.dp).clip(RoundedCornerShape(6.dp)),
                                    contentScale = ContentScale.Crop)
                                Spacer(Modifier.width(12.dp))
                                Column(Modifier.weight(1f)) {
                                    val head = c.name.ifBlank { c.text.lines().firstOrNull { it.isNotBlank() } ?: "(no text found)" }
                                    Text(head, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                    if (c.company.isNotBlank()) Text(c.company, maxLines = 1, overflow = TextOverflow.Ellipsis,
                                        style = MaterialTheme.typography.bodyMedium)
                                    if (c.phone.isNotBlank()) Text(c.phone, maxLines = 1, overflow = TextOverflow.Ellipsis,
                                        style = MaterialTheme.typography.bodySmall)
                                }
                                IconButton({ vm.toggleFavorite(c) }) {
                                    Icon(if (c.favorite) Icons.Default.Star else Icons.Default.StarBorder, "Favourite")
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

// ---------------------------------------------------------------- ADD
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddScreen(vm: CardViewModel, onDone: () -> Unit) {
    val ctx = LocalContext.current
    var pending by rememberSaveable { mutableStateOf("") }
    var target by rememberSaveable { mutableStateOf("") }
    var front by rememberSaveable { mutableStateOf("") }
    var back by rememberSaveable { mutableStateOf("") }
    var note by rememberSaveable { mutableStateOf("") }
    var busy by rememberSaveable { mutableStateOf(false) }

    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.TakePicture()) { ok ->
        if (ok) { if (target == "front") front = pending else back = pending }
    }
    fun shoot(which: String) {
        val dir = File(ctx.filesDir, "cards").apply { mkdirs() }
        val f = File(dir, "${UUID.randomUUID()}.jpg")
        pending = f.absolutePath; target = which
        launcher.launch(FileProvider.getUriForFile(ctx, "${ctx.packageName}.fileprovider", f))
    }

    Scaffold(topBar = {
        TopAppBar(
            title = { Text("New card") },
            navigationIcon = { IconButton(onDone) { Icon(Icons.Default.ArrowBack, null) } })
    }) { pad ->
        Column(Modifier.padding(pad).padding(16.dp).verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(14.dp)) {
            Slot("Front side", front) { if (!busy) shoot("front") }
            Slot("Back side (optional)", back) { if (!busy) shoot("back") }
            OutlinedTextField(note, { note = it }, label = { Text("Note (optional) e.g. met at Dairy Expo") },
                modifier = Modifier.fillMaxWidth())
            Button(
                onClick = { busy = true; vm.save(front, back.ifBlank { null }, note, onDone) },
                enabled = front.isNotBlank() && !busy,
                modifier = Modifier.fillMaxWidth()
            ) {
                if (busy) {
                    CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp)
                    Spacer(Modifier.width(10.dp)); Text("Reading text…")
                } else Text("Save card")
            }
        }
    }
}

@Composable
private fun Slot(label: String, path: String, onClick: () -> Unit) {
    Card(Modifier.fillMaxWidth().height(190.dp).clickable(onClick = onClick)) {
        if (path.isBlank()) {
            Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.Center,
                horizontalAlignment = Alignment.CenterHorizontally) {
                Icon(Icons.Default.AddAPhoto, null, Modifier.size(40.dp))
                Spacer(Modifier.height(8.dp))
                Text("Tap to photograph: $label")
            }
        } else {
            AsyncImage(File(path), label, Modifier.fillMaxSize(), contentScale = ContentScale.Fit)
        }
    }
}

// ---------------------------------------------------------------- DETAIL
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DetailScreen(vm: CardViewModel, id: Long, onBack: () -> Unit) {
    val ctx = LocalContext.current
    var card by remember { mutableStateOf<CardEntity?>(null) }
    var name by remember { mutableStateOf("") }
    var company by remember { mutableStateOf("") }
    var title by remember { mutableStateOf("") }
    var phone by remember { mutableStateOf("") }
    var email by remember { mutableStateOf("") }
    var website by remember { mutableStateOf("") }
    var address by remember { mutableStateOf("") }
    var text by remember { mutableStateOf("") }
    var note by remember { mutableStateOf("") }
    var fav by remember { mutableStateOf(false) }
    var confirmDelete by remember { mutableStateOf(false) }

    LaunchedEffect(id) {
        vm.getCard(id)?.let {
            card = it; name = it.name; company = it.company; title = it.title; phone = it.phone
            email = it.email; website = it.website; address = it.address; text = it.text; note = it.note
            fav = it.favorite
        }
    }
    val c = card
    fun firstPhone() = phone.split(",").firstOrNull()?.trim().orEmpty()

    Scaffold(topBar = {
        TopAppBar(
            title = { Text("Card") },
            navigationIcon = { IconButton(onBack) { Icon(Icons.Default.ArrowBack, null) } },
            actions = {
                IconButton({ fav = !fav }) { Icon(if (fav) Icons.Default.Star else Icons.Default.StarBorder, "Favourite") }
                IconButton({ confirmDelete = true }) { Icon(Icons.Default.Delete, "Delete") }
            })
    }) { pad ->
        if (c == null) return@Scaffold
        Column(Modifier.padding(pad).padding(16.dp).verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(10.dp)) {
            AsyncImage(File(c.frontPath), "Front", Modifier.fillMaxWidth().heightIn(max = 240.dp), contentScale = ContentScale.Fit)
            c.backPath?.let {
                AsyncImage(File(it), "Back", Modifier.fillMaxWidth().heightIn(max = 240.dp), contentScale = ContentScale.Fit)
            }

            // Quick actions
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                IconButton({ if (firstPhone().isNotBlank()) launch(ctx, Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + firstPhone().filter { it.isDigit() || it == '+' }))) }) {
                    Icon(Icons.Default.Call, "Call") }
                IconButton({
                    val digits = firstPhone().filter { it.isDigit() }
                    if (digits.isNotBlank()) {
                        val full = if (digits.length == 10) "91$digits" else digits
                        launch(ctx, Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/$full")))
                    }
                }) { Icon(Icons.Default.Chat, "WhatsApp") }
                IconButton({ if (email.isNotBlank()) launch(ctx, Intent(Intent.ACTION_SENDTO, Uri.parse("mailto:${email.trim()}"))) }) {
                    Icon(Icons.Default.Email, "Email") }
                IconButton({
                    if (website.isNotBlank()) {
                        val w = website.trim().let { if (it.startsWith("http", true)) it else "https://$it" }
                        launch(ctx, Intent(Intent.ACTION_VIEW, Uri.parse(w)))
                    }
                }) { Icon(Icons.Default.Language, "Website") }
                IconButton({
                    val i = Intent(ContactsContract.Intents.Insert.ACTION).apply {
                        type = ContactsContract.RawContacts.CONTENT_TYPE
                        putExtra(ContactsContract.Intents.Insert.NAME, name)
                        putExtra(ContactsContract.Intents.Insert.COMPANY, company)
                        putExtra(ContactsContract.Intents.Insert.JOB_TITLE, title)
                        putExtra(ContactsContract.Intents.Insert.PHONE, firstPhone())
                        putExtra(ContactsContract.Intents.Insert.EMAIL, email.trim())
                        putExtra(ContactsContract.Intents.Insert.POSTAL, address)
                        putExtra(ContactsContract.Intents.Insert.NOTES, note)
                    }
                    launch(ctx, i)
                }) { Icon(Icons.Default.PersonAdd, "Save to phone contacts") }
            }

            OutlinedTextField(name, { name = it }, label = { Text("Name") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
            OutlinedTextField(company, { company = it }, label = { Text("Company") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
            OutlinedTextField(title, { title = it }, label = { Text("Designation") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
            OutlinedTextField(phone, { phone = it }, label = { Text("Phone(s)") }, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(email, { email = it }, label = { Text("Email") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
            OutlinedTextField(website, { website = it }, label = { Text("Website") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
            OutlinedTextField(address, { address = it }, label = { Text("Address") }, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(note, { note = it }, label = { Text("Note") }, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(text, { text = it }, label = { Text("All text on card (searchable)") },
                modifier = Modifier.fillMaxWidth(), minLines = 4)

            OutlinedButton({
                val p = Parse.parse(text)
                name = p.name; company = p.company; title = p.title
                phone = p.phone; email = p.email; website = p.website; address = p.address
            }, Modifier.fillMaxWidth()) {
                Icon(Icons.Default.AutoFixHigh, null); Spacer(Modifier.width(8.dp)); Text("Re-detect fields from text")
            }
            Button({
                vm.update(c.copy(name = name, company = company, title = title, phone = phone, email = email,
                    website = website, address = address, text = text, note = note, favorite = fav))
                onBack()
            }, Modifier.fillMaxWidth()) { Text("Save changes") }
        }
        if (confirmDelete) {
            AlertDialog(
                onDismissRequest = { confirmDelete = false },
                title = { Text("Delete this card?") },
                confirmButton = { TextButton({ vm.delete(c); onBack() }) { Text("Delete") } },
                dismissButton = { TextButton({ confirmDelete = false }) { Text("Cancel") } })
        }
    }
}
