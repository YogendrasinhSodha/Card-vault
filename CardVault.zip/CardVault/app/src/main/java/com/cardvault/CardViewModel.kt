package com.cardvault

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*
import java.io.File

class CardViewModel(app: Application) : AndroidViewModel(app) {
    private val dao = AppDb.get(app).dao()
    val query = MutableStateFlow("")
    val favOnly = MutableStateFlow(false)

    @OptIn(ExperimentalCoroutinesApi::class)
    val cards: StateFlow<List<CardEntity>> = combine(query, favOnly) { q, f -> q.trim() to f }
        .flatMapLatest { (q, f) -> dao.search(q, if (f) 1 else 0) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    suspend fun getCard(id: Long) = dao.get(id)
    suspend fun allCards() = dao.allNow()

    /** Runs OCR on both sides, detects fields, then saves the card. */
    fun save(front: String, back: String?, note: String, onDone: () -> Unit) {
        viewModelScope.launch {
            val text = withContext(Dispatchers.Default) {
                val parts = mutableListOf<String>()
                parts += Ocr.read(getApplication(), Images.normalize(front))
                if (back != null) parts += Ocr.read(getApplication(), Images.normalize(back))
                parts.filter { it.isNotBlank() }.joinToString("\n\n")
            }
            val p = Parse.parse(text)
            dao.insert(CardEntity(
                frontPath = front, backPath = back, text = text, note = note,
                name = p.name, company = p.company, title = p.title, phone = p.phone,
                email = p.email, website = p.website, address = p.address))
            onDone()
        }
    }

    fun update(card: CardEntity) = viewModelScope.launch { dao.update(card) }

    fun toggleFavorite(card: CardEntity) = viewModelScope.launch { dao.update(card.copy(favorite = !card.favorite)) }

    fun delete(card: CardEntity) = viewModelScope.launch {
        dao.delete(card)
        withContext(Dispatchers.IO) {
            File(card.frontPath).delete()
            card.backPath?.let { File(it).delete() }
        }
    }
}
