package com.cardvault

import android.content.Context
import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "cards")
data class CardEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val frontPath: String,
    val backPath: String?,
    val text: String,              // raw OCR text (English + Gujarati), editable
    val note: String = "",
    val name: String = "",
    val company: String = "",
    val title: String = "",
    val phone: String = "",
    val email: String = "",
    val website: String = "",
    val address: String = "",
    val favorite: Boolean = false,
    val createdAt: Long = System.currentTimeMillis()
)

@Dao
interface CardDao {
    @Query(
        "SELECT * FROM cards WHERE (:fav = 0 OR favorite = 1) AND (" +
            "text LIKE '%' || :q || '%' OR note LIKE '%' || :q || '%' OR " +
            "name LIKE '%' || :q || '%' OR company LIKE '%' || :q || '%' OR " +
            "title LIKE '%' || :q || '%' OR phone LIKE '%' || :q || '%' OR " +
            "email LIKE '%' || :q || '%' OR address LIKE '%' || :q || '%') " +
            "ORDER BY createdAt DESC"
    )
    fun search(q: String, fav: Int): Flow<List<CardEntity>>

    @Query("SELECT * FROM cards ORDER BY createdAt DESC")
    suspend fun allNow(): List<CardEntity>

    @Query("SELECT * FROM cards WHERE id = :id")
    suspend fun get(id: Long): CardEntity?

    @Insert suspend fun insert(card: CardEntity): Long
    @Update suspend fun update(card: CardEntity)
    @Delete suspend fun delete(card: CardEntity)
}

@Database(entities = [CardEntity::class], version = 2, exportSchema = false)
abstract class AppDb : RoomDatabase() {
    abstract fun dao(): CardDao

    companion object {
        @Volatile private var inst: AppDb? = null
        fun get(ctx: Context): AppDb = inst ?: synchronized(this) {
            inst ?: Room.databaseBuilder(ctx.applicationContext, AppDb::class.java, "cards.db")
                .fallbackToDestructiveMigration()
                .build().also { inst = it }
        }
    }
}
