package com.cardvault

import android.content.Context
import android.content.Intent
import androidx.core.content.FileProvider
import java.io.File

object Export {
    private fun esc(s: String) = "\"" + s.replace("\"", "\"\"").replace("\n", " ") + "\""

    /** Writes all cards to a CSV (opens in Excel / Google Sheets, Gujarati safe) and opens the share sheet. */
    fun shareCsv(ctx: Context, cards: List<CardEntity>) {
        val dir = File(ctx.cacheDir, "exports").apply { mkdirs() }
        val f = File(dir, "cards.csv")
        val sb = StringBuilder("\uFEFF")
        sb.append("Name,Company,Title,Phone,Email,Website,Address,Note,Favorite,All text\n")
        for (c in cards) {
            sb.append(listOf(c.name, c.company, c.title, c.phone, c.email, c.website, c.address, c.note,
                if (c.favorite) "Yes" else "", c.text).joinToString(",") { esc(it) }).append("\n")
        }
        f.writeText(sb.toString(), Charsets.UTF_8)
        val uri = FileProvider.getUriForFile(ctx, "${ctx.packageName}.fileprovider", f)
        val send = Intent(Intent.ACTION_SEND).apply {
            type = "text/csv"
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        ctx.startActivity(Intent.createChooser(send, "Export cards").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }
}
