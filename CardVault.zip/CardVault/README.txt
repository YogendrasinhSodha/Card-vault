CARD VAULT - Android visiting card organiser
Photo of front + back -> offline OCR (English + Gujarati) -> searchable list.

BUILD OPTION A - no Android Studio (GitHub builds the APK for you)
1. Create a free GitHub account, make a new repository, upload ALL files of this folder (including the hidden .github folder).
2. Open the repository > Actions tab > 'Build APK' > Run workflow. After ~5 minutes download 'CardVault-APK' from the run page, unzip, install app-debug.apk on the phone.

BUILD OPTION B - Android Studio
1. Install Android Studio (free). Open this folder (CardVault) with File > Open.
2. Wait for Gradle sync (first time downloads ~ 500 MB; needs internet).
3. Phone: Settings > About > tap Build number 7 times > Developer options > USB debugging ON.
   Connect by USB, press the green Run button.
   OR: Build > Build APK(s) -> app/build/outputs/apk/debug/app-debug.apk, send to phone and install.

NOTES
- Everything is stored on the phone only. No internet needed after install.
- OCR language files are in app/src/main/assets/tessdata (eng, guj). Gujarati on printed cards works well;
  stylised/decorative fonts may read poorly. Text can be corrected in the card screen.
- If Gradle cannot find tesseract4android on Maven Central, add
  maven("https://jitpack.io") to repositories in settings.gradle.kts and change the dependency to
  "com.github.adaptech-cz:Tesseract4Android:4.7.0".
